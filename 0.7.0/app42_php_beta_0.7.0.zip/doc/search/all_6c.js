var searchData=
[
  ['level',['Level',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1app_tab_1_1_level.html',1,'com::shephertz::app42::paas::sdk::php::appTab']]],
  ['leveltransaction',['LevelTransaction',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1app_tab_1_1_level_transaction.html',1,'com::shephertz::app42::paas::sdk::php::appTab']]],
  ['license',['License',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1app_tab_1_1_license.html',1,'com::shephertz::app42::paas::sdk::php::appTab']]],
  ['licenseresponsebuilder',['LicenseResponseBuilder',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1app_tab_1_1_license_response_builder.html',1,'com::shephertz::app42::paas::sdk::php::appTab']]],
  ['licenseservice',['LicenseService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1app_tab_1_1_license_service.html',1,'com::shephertz::app42::paas::sdk::php::appTab']]],
  ['licensetransaction',['LicenseTransaction',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1app_tab_1_1_license_transaction.html',1,'com::shephertz::app42::paas::sdk::php::appTab']]],
  ['linkappcredentials',['linkAppCredentials',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1social_1_1_facebook_service.html#a73593f501aaa1d3e6397abb71aeb2c16',1,'com\shephertz\app42\paas\sdk\php\social\FacebookService\linkAppCredentials()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1social_1_1_twitter_service.html#a55904d49d7d5e4452af5e762c509b719',1,'com\shephertz\app42\paas\sdk\php\social\TwitterService\linkAppCredentials()']]],
  ['linkuserfacebookaccount',['linkUserFacebookAccount',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1social_1_1_facebook_service.html#a8e8faacc0774c49307b04da6ea16cf03',1,'com::shephertz::app42::paas::sdk::php::social::FacebookService']]],
  ['linkusertwitteraccount',['linkUserTwitterAccount',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1social_1_1_twitter_service.html#a3fb9bc31762c7932ee9ba35ce04f717d',1,'com::shephertz::app42::paas::sdk::php::social::TwitterService']]],
  ['loadpreferencefile',['loadPreferenceFile',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1recommend_1_1_recommender_service.html#a2275caa2e24995cd19c5d0d143e12110',1,'com::shephertz::app42::paas::sdk::php::recommend::RecommenderService']]],
  ['lockuser',['lockUser',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1user_1_1_user_service.html#a482854ed5da446e1249bc1919f688d6d',1,'com::shephertz::app42::paas::sdk::php::user::UserService']]],
  ['log',['Log',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1log_1_1_log.html',1,'com::shephertz::app42::paas::sdk::php::log']]],
  ['logresponsebuilder',['LogResponseBuilder',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1log_1_1_log_response_builder.html',1,'com::shephertz::app42::paas::sdk::php::log']]],
  ['logservice',['LogService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1log_1_1_log_service.html',1,'com::shephertz::app42::paas::sdk::php::log']]]
];
