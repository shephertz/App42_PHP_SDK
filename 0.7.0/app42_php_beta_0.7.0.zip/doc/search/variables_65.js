var searchData=
[
  ['euclidean_5fdistance',['EUCLIDEAN_DISTANCE',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1recommend_1_1_recommender_similarity.html#ad5bbd2ff6a9b3c69ed6a35a08ee047b0',1,'com::shephertz::app42::paas::sdk::php::recommend::RecommenderSimilarity']]]
];
