var searchData=
[
  ['gb',['GB',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1app_tab_1_1_usage_band_width.html#a289c360455c31eedfe4f6cde03c47c4b',1,'com\shephertz\app42\paas\sdk\php\appTab\UsageBandWidth\GB()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1app_tab_1_1_usage_storage.html#a289c360455c31eedfe4f6cde03c47c4b',1,'com\shephertz\app42\paas\sdk\php\appTab\UsageStorage\GB()']]]
];
