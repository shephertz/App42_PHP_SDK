var searchData=
[
  ['apple',['apple',['../namespacecom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php.html#acaa98ca68ab6a6c1ef97e8285ab08b0f',1,'com::shephertz::app42::paas::sdk::php']]],
  ['audio',['AUDIO',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1upload_1_1_upload_file_type.html#a9f6cfe013372d7de1568a95c871214d1',1,'com::shephertz::app42::paas::sdk::php::upload::UploadFileType']]],
  ['authorized',['AUTHORIZED',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1shopping_1_1_payment_status.html#a733cdce623d01b4164a01652375bc7e4',1,'com::shephertz::app42::paas::sdk::php::shopping::PaymentStatus']]]
];
