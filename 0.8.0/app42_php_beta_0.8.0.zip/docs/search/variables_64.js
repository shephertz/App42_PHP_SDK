var searchData=
[
  ['declined',['DECLINED',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1shopping_1_1_payment_status.html#af0e3a2596ff8af1e988f1f0e7dfc3ab3',1,'com::shephertz::app42::paas::sdk::php::shopping::PaymentStatus']]]
];
