var searchData=
[
  ['additem',['addItem',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1shopping_1_1_cart_service.html#a681ec91e10e412828b2a0cbe762d66ae',1,'com\shephertz\app42\paas\sdk\php\shopping\CartService\addItem()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1shopping_1_1_catalogue_service.html#a9c8281af7e60514137e51b878c6c6f54',1,'com\shephertz\app42\paas\sdk\php\shopping\CatalogueService\addItem()']]],
  ['addorupdatepreference',['addOrUpdatePreference',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1recommend_1_1_recommender_service.html#a02ab0bbcd370c828014625648116fa9f',1,'com::shephertz::app42::paas::sdk::php::recommend::RecommenderService']]],
  ['addphoto',['addPhoto',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1gallery_1_1_photo_service.html#af298d9c0d41a5607a7c560f241ccc62c',1,'com::shephertz::app42::paas::sdk::php::gallery::PhotoService']]],
  ['addscore',['addScore',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1game_1_1_score_service.html#a1967742ab084fd9c30cd13335399ac26',1,'com::shephertz::app42::paas::sdk::php::game::ScoreService']]],
  ['addtagtophoto',['addTagToPhoto',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1gallery_1_1_photo_service.html#a4fdde5fc13818dd5fdc9fff40cf7ce7d',1,'com::shephertz::app42::paas::sdk::php::gallery::PhotoService']]],
  ['app42exception1',['App42Exception1',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1_app42_exception.html#ab0da731796782133a8a6c871755ea301',1,'com::shephertz::app42::paas::sdk::php::App42Exception']]],
  ['app42exception2',['App42Exception2',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1_app42_exception.html#a61587ac35fa4759d47549fd2700664fd',1,'com::shephertz::app42::paas::sdk::php::App42Exception']]],
  ['app42exception3',['App42Exception3',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1_app42_exception.html#a9856b8739b4f4aa9bfabfa63aa23164d',1,'com::shephertz::app42::paas::sdk::php::App42Exception']]],
  ['assignroles',['assignRoles',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1user_1_1_user_service.html#ac892b43848dd337e5c3a061e083dae34',1,'com::shephertz::app42::paas::sdk::php::user::UserService']]],
  ['authenticate',['authenticate',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1user_1_1_user_service.html#a0399a1547a735e805f32a78dfb0c6536',1,'com::shephertz::app42::paas::sdk::php::user::UserService']]]
];
