var searchData=
[
  ['pearson_5fcorrelation',['PEARSON_CORRELATION',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1recommend_1_1_recommender_similarity.html#acc92e75b65f4c3fc0cccdffa7ac12cc5',1,'com::shephertz::app42::paas::sdk::php::recommend::RecommenderSimilarity']]],
  ['pending',['PENDING',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1shopping_1_1_payment_status.html#abaf4facc752f618f7d88aa7e2886c812',1,'com::shephertz::app42::paas::sdk::php::shopping::PaymentStatus']]],
  ['plain_5ftext_5fmime_5ftype',['PLAIN_TEXT_MIME_TYPE',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1email_1_1_email_m_i_m_e.html#ae360082cc38a8ad4ee871eeeec8d78a8',1,'com::shephertz::app42::paas::sdk::php::email::EmailMIME']]]
];
