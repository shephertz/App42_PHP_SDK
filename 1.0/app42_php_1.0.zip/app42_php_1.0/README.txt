//App42 PHP SDK

1. UnZip the downloaded file
2. This will contain App42_PHP_SDK_x.x.x.zip ,doc, sample Folder and README.txt
3. doc folder contains API docs
4. Sample folder contains PHP sample project for using App42 PHP SDK.
5. Please visit http://api.shephertz.com/cloudapidocs/index.php for detail documentaion.

-----------------------------------------------------------------------------------------------------------

How To run Sample App : Copy the SampleApp.php into App42_PHP_SDK_x.x.x Folder and you are ready to go.

-----------------------------------------------------------------------------------------------------------

NOTE : You have to open curl settings in php.ini file

Steps: Open php.ini ---> search with keyword "curl" ---> remove ";" before "extension=php_curl.dll"