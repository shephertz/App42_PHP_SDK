var searchData=
[
  ['mapreduce',['mapReduce',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1storage_1_1_storage_service.html#a2c95b1ca9754d616b3af34636f663c44',1,'com::shephertz::app42::paas::sdk::php::storage::StorageService']]],
  ['mute',['mute',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1review_1_1_review_service.html#a0f39e6daa155ac512ba9aa1c528e7060',1,'com::shephertz::app42::paas::sdk::php::review::ReviewService']]]
];
