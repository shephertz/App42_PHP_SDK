<?php namespace com\shephertz\app42\paas\sdk\php;
define("HOST","localhost");
define("PORT","8082");
define("Connection","REST");
define("CONTENT_TYPE","application/json");
define("ACCEPT","application/json");
?>