App42_PHP_API
=============

App42 PHP Client SDK