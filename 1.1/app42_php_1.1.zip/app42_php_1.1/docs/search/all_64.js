var searchData=
[
  ['debug',['debug',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1_app42_log.html#ae8b3566574ed36b500a4e3693e67833b',1,'com\shephertz\app42\paas\sdk\php\App42Log\debug()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1log_1_1_log_service.html#a49c41e3a2b535b938c7e14c000d5b472',1,'com\shephertz\app42\paas\sdk\php\log\LogService\debug()']]],
  ['december',['DECEMBER',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1app_tab_1_1_bill_month.html#a59d635080505436fbba4d05cff273835',1,'com::shephertz::app42::paas::sdk::php::appTab::BillMonth']]],
  ['declined',['DECLINED',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1shopping_1_1_payment_status.html#af0e3a2596ff8af1e988f1f0e7dfc3ab3',1,'com::shephertz::app42::paas::sdk::php::shopping::PaymentStatus']]],
  ['decreasequantity',['decreaseQuantity',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1shopping_1_1_cart_service.html#a52b92a1e9621ade18ae387b0f8a83657',1,'com::shephertz::app42::paas::sdk::php::shopping::CartService']]],
  ['deductscore',['deductScore',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1game_1_1_score_service.html#a2899145623ded43fd85cbfd734e53f6d',1,'com::shephertz::app42::paas::sdk::php::game::ScoreService']]],
  ['delete',['delete',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1connection_1_1_rest_client.html#a361d511b5e202d7529a2a35f206f260f',1,'com::shephertz::app42::paas::sdk::php::connection::RestClient']]],
  ['deleteallpreferences',['deleteAllPreferences',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1recommend_1_1_recommender_service.html#a468ae67c8db20494d0197d4887c5668a',1,'com::shephertz::app42::paas::sdk::php::recommend::RecommenderService']]],
  ['deletedocumentbyid',['deleteDocumentById',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1storage_1_1_storage_service.html#abbf6f3d1aa976cd2fab02a37af34cb8c',1,'com::shephertz::app42::paas::sdk::php::storage::StorageService']]],
  ['deletepullqueue',['deletePullQueue',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1message_1_1_queue_service.html#a6888017f56f2be2e0b67dfb1427487fa',1,'com::shephertz::app42::paas::sdk::php::message::QueueService']]],
  ['deletestorage',['deleteStorage',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1geo_1_1_geo_service.html#a1fdf486ca1ba0834e3921ad6009a2768',1,'com::shephertz::app42::paas::sdk::php::geo::GeoService']]],
  ['deleteuser',['deleteUser',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1user_1_1_user_service.html#a2686e125d02a182347c15dead8636740',1,'com::shephertz::app42::paas::sdk::php::user::UserService']]],
  ['descending',['DESCENDING',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1storage_1_1_order_by_type.html#ae9122b532d9ebc38e2096506761d13f4',1,'com::shephertz::app42::paas::sdk::php::storage::OrderByType']]],
  ['devicetype',['DeviceType',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1php_1_1push_1_1_device_type.html',1,'com::shephertz::app42::paas::sdk::php::push']]]
];
